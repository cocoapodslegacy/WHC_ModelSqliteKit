#import <Foundation/Foundation.h>

//! Project version number for WHC_ModelSqliteKit.
FOUNDATION_EXPORT double WHC_ModelSqliteKitVersionNumber;

//! Project version string for WHC_ModelSqliteKit.
FOUNDATION_EXPORT const unsigned char WHC_ModelSqliteKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WHC_ModelSqliteKit/PublicHeader.h>
#import <WHC_ModelSqliteKit/WHC_ModelSqlite.h>


